<?php
require_once 'koneksi.php';$nama_toko='';$meta_deskripsi='';$meta_keyword='';$email_pengelola='';
$nomor_hp='';$nomor_rekening='';
