<?php
session_start();
if (empty($_SESSION['username']) AND empty($_SESSION['passuser'])){
  echo "<link href='style.css' rel='stylesheet' type='text/css'>
 <center>Untuk mengakses modul, Anda harus login <br>";
  echo "<a href=../../index.php><b>LOGIN</b></a></center>";
}
else{
include "../../../config/koneksi.php";
include "../../../config/fungsi_thumb.php";

$module=$_GET['module'];
$act=$_GET['act'];

// Update identitas
if ($module=='identitas' AND $act=='update'){
  $lokasi_file = $_FILES['fupload']['tmp_name'];
  $nama_file   = $_FILES['fupload']['name'];

  // Apabila ada gambar yang diupload
  if (!empty($lokasi_file)){
    UploadFavicon($nama_file);
    mysqli_query($con,"UPDATE identitas SET nama_website   = '$_POST[nama_website]',
									  alamat_web     = '$_POST[alamat_web]',
									  email          = '$_POST[email]',
									  telp			 ='$_POST[telp]',
									  link_web		 ='$_POST[link_web]',
									   link_twitter ='$_POST[link_twitter]',
									  link_fb ='$_POST[link_fb]',
                                      meta_deskripsi = '$_POST[meta_deskripsi]',
                                      meta_keyword   = '$_POST[meta_keyword]',
                                      favicon        = '$nama_file'    
                                WHERE id_identitas   = '$_POST[id]'");
  }
  else{
    mysqli_query($con,"UPDATE identitas SET nama_website   = '$_POST[nama_website]',
									  alamat_web     = '$_POST[alamat_web]',
									   email          = '$_POST[email]',
									  telp			 ='$_POST[telp]',
									  link_web		 ='$_POST[link_web]',
									   link_twitter ='$_POST[link_twitter]',
									  link_fb ='$_POST[link_fb]',
                                      meta_deskripsi = '$_POST[meta_deskripsi]',
                                      meta_keyword   = '$_POST[meta_keyword]'
                                WHERE id_identitas   = '$_POST[id]'");
  }
  header('location:../../media.php?module='.$module);
}
}
?>
